package com.example.nesflis;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;

public class MainActivity extends AppCompatActivity {
    private EditText nombre_pelicula;
    private Button boton_buscar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre_pelicula = findViewById(R.id.editText);
        boton_buscar = findViewById(R.id.btnBuscar);
    }
}
